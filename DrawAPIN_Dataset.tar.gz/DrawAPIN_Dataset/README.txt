This is the data set collected and used in the paper below:
(1) Toan Nguyen, Napa Sae-Bae, and Nasir Memon. "DRAW-A-PIN: Authentication using finger-drawn PIN on touch devices." Computers & Security 66 (2017): 115-128.

To use this data set, you agree to the following restrictions:
- Do not attempt to de-anonymize the individuals (volunteers) who have contributed the data.
- Any of your publication that benefits from the this data set must cite the following articles:

Toan Nguyen, Napa Sae-Bae, and Nasir Memon. "DRAW-A-PIN: Authentication using finger-drawn PIN on touch devices." Computers & Security 66 (2017): 115-128.
bibtex:
@article{van2017draw,
  title={DRAW-A-PIN: Authentication using finger-drawn PIN on touch devices},
  author={Van Nguyen, Toan and Sae-Bae, Napa and Memon, Nasir},
  journal={Computers \& Security},
  volume={66},
  pages={115--128},
  year={2017},
  publisher={Elsevier}
}

and
Toan Nguyen, Napa Sae-Bae, and Nasir Memon. "Finger-drawn pin authentication on touch devices." Image Processing (ICIP), 2014 IEEE International Conference on. IEEE, 2014.
bibtex:
@inproceedings{van2014finger,
  title={Finger-drawn pin authentication on touch devices},
  author={Van Nguyen, Toan and Sae-Bae, Napa and Memon, Nasir},
  booktitle={Image Processing (ICIP), 2014 IEEE International Conference on},
  pages={5002--5006},
  year={2014},
  organization={IEEE}
}


DATA FORMAT
- The data includes a Users.txt file which lists all users and their PINs in our data set.
- 20 directories for 20 users. In each user dir, there are 4 subdirs
  + Enrollment dir contains 5 enrollment sessions of the PIN of the user
      + In each enrollment session dir, raw data of each digit of the PIN is stored in a text file with following format
        {UserID_enroll}_{datetime}_{digit}.txt
        For example, User1_enroll_20140917_18_20_23_1.txt contains the raw data of the first digit in the PIN of User1
        User1_enroll_20140917_18_20_26_2.txt contains the raw data of the second digit in the PIN of User1
        and so on.
        Files with "invisible" suffix (i.e., User5_login_20140930_11_42_14_3_invisible.txt) belongs to "invisible PIN", which was drawn without visual feedback on the screen. Please refer to our journal paper for more details.
  + Login dir contains all login samples of the user. It contains subdirs for each day the user logged into her/his phone using DrawAPIN system. In each subdir for each day, each login sample is stored in a session dir. In each session dir, raw data of the PIN is stored with the same naming format as in Enrollment samples.
  + ImitationAttack and PINAttack dir contain samples of the two attacks presented in paper (1). In each dir, there are several subdirs, each subdir stores samples of an attacker for that attack.
  In each attacker dir, there are 5 attack samples (numbered from 1 to 5). In each of these sample dirs, raw data of each digit is stored in a text file with similar naming format as above: {AttackerID}_{datetime}_{digit}.txt
  For example, Attacker1_1715_20141010_18_03_55_1.txt contains the raw data of the first digit of Attacker1
  
Please direct all questions regarding to this data set and the two papers listed above to Toan Nguyen at toan.v.nguyen@nyu.edu
  
  